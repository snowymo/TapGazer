﻿using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("TobiiXRDevTools")]
[assembly: InternalsVisibleTo("TobiiXRExamples")]
[assembly: InternalsVisibleTo("TobiiXRInternalEditor")]
