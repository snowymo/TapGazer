﻿using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("TobiiXRTests")]
[assembly: InternalsVisibleTo("TobiiXRTestsEditor")]