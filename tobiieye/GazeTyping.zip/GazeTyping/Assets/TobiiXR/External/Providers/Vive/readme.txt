The HTC Provider relies on HTC SR Anipal SDK Unity plugin being added to your project. Download it from https://hub.vive.com/en-US/profile/material-download.
