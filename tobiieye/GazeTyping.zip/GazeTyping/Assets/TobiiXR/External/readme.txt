Code placed in this folder has dependencies on external libraries that needs to be downloaded separately from Tobii XR SDK. See under each folder for more details.
